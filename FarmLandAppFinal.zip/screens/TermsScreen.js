import React from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import * as Icon from "react-native-feather";
import { useNavigation } from "@react-navigation/native";

export default function TermsScreen() {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "white" }}>
      {/* Encabezado superior */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 20,
          paddingVertical: 15,
          backgroundColor: "#e0f2fe",
          borderBottomWidth: 1,
          borderColor: "#dbeafe",
        }}
      >
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{
            padding: 6,
            borderRadius: 20,
            backgroundColor: "white",
            shadowColor: "#000",
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 2,
          }}
        >
          <Icon.ArrowLeft width={20} height={20} stroke="#3b82f6" />
        </TouchableOpacity>

        <Text
          style={{
            flex: 1,
            textAlign: "center",
            fontSize: 18,
            fontWeight: "bold",
            color: "#1E3A8A",
            marginRight: 30,
          }}
        >
          Terms of use
        </Text>
      </View>

      {/* Contenido desplazable */}
      <ScrollView style={{ padding: 20 }}>
        <Text
          style={{
            fontSize: 16,
            lineHeight: 24,
            color: "#374151",
            marginBottom: 15,
          }}
        >
          Welcome to our application. By using our services, you agree to the
          following terms and conditions. Please read them carefully.
        </Text>

        <Text
          style={{
            fontSize: 18,
            fontWeight: "600",
            marginTop: 20,
            color: "#111827",
          }}
        >
          Ussing the app
        </Text>
        <Text style={{ fontSize: 15, lineHeight: 22, color: "#4B5563" }}>
          PLEASE READ THESE TERMS OF USE CAREFULLY. ACCESSING OR USING THIS
          WEBSITE CONSTITUTES ACCEPTANCE OF THESE TERMS OF USE (“TERMS”), AS
          SUCH MAY BE REVISED BY FARMLAND DELI FROM TIME TO TIME, AND IS A
          BINDING AGREEMENT BETWEEN THE USER (“USER” OR “YOU”) AND Quick
          Catering Inc. (D/B/A Farmland Deli) GOVERNING THE USE OF THE WEBSITE.
          IF USER DOES NOT AGREE TO THESE TERMS, USER SHOULD NOT ACCESS OR USE
          THIS WEBSITE. THESE TERMS CONTAIN DISCLAIMERS AND OTHER PROVISIONS
          THAT LIMIT OUR LIABILITY TO USER. These Terms apply to your access to,
          and use of, all or part of any website, web application, or mobile
          application of Farmland Deli Corporation or its subsidiaries and
          affiliated companies (collectively, “Farmland”), including
          https://www.clover.com/online-ordering/farmland-deli and any other
          site, mobile application, web application, or online service where
          these Terms are posted (collectively, the “Sites”). These Terms do not
          alter in any way the terms or conditions of any other agreement you
          may have with Farmland Deli for products, services or otherwise. In
          the event there is any conflict or inconsistency between these Terms
          and any other terms of use that appear on the Sites, these Terms will
          govern. However, if you navigate away from the Sites to a third-party
          site, you may be subject to alternative terms and conditions of use,
          as may be specified on such site, which will govern your use of that
          site. While we make reasonable efforts to provide accurate and timely
          information about Farmland Deli on the Sites, you should not assume
          that the information is always up to date or that the Sites contain
          all the relevant information available about Farmland Deli. In
          particular, if you are making an investment decision regarding
          Farmland Deli, please consult a number of different sources, including
          Farmland Deli filings with the Securities and Exchange Commission.
          These Terms include an arbitration agreement that governs any disputes
          between you and us. In arbitration, there is less discovery and
          appellate review than in court. This arbitration agreement and other
          provisions will: ● Eliminate your right to a trial by jury to the
          extent allowable under applicable law; and ● Substantially affect your
          rights, including preventing you from bringing, joining or
          participating in class or consolidated proceedings in arbitration and
          litigation. You agree that we may provide notices, disclosures and
          amendments to these Terms by electronic means, including by changing
          these Terms by posting revisions on the Sites. See also: Farmland Deli
          Points for Everything Terms Eligibility The Sites are not targeted
          towards, nor intended for use by, anyone under the age of 13. A USER
          MUST BE AT LEAST AGE 13 TO ACCESS AND USE THE SITES. If the User is
          between the ages of 13 and 18, he or she may only use the Sites under
          the supervision of a parent or legal guardian who agrees to be bound
          by these Terms. User represents and warrants that (a) he/she is not
          located in a country that is subject to a U.S. government embargo, or
          that has been designated by the U.S. government as a “terrorist
          supporting” country; and (b) he/she is not listed on any U.S.
          government list of prohibited or restricted parties. In order to
          participate in certain areas or use certain functions of our Sites,
          you may need to register for an account. You agree to (a) create only
          one account; (b) provide accurate, truthful , current and complete
          information when creating your account; (c) maintain and promptly
          update your account information; (d) maintain the security of your
          account by not sharing your password with others and restricting
          access to your account and your computer; (e) promptly notify Farmland
          Deli if you discover or otherwise suspect any security breaches
          relating to the Sites; and (f) take responsibility for all activities
          that occur under your account and accept all risks of unauthorized
          access. Privacy Please read the Privacy Policy carefully to understand
          how Farmland Deli collects, uses and discloses personally identifiable
          information from its users. By accessing or using the Sites, you
          consent to all actions that we take with respect to your data
          consistent with our Privacy Policy. Farmland Deli Points for
          Everything Rewards Program Farmland Deli may allow you to register for
          its Points for Everything (“Rewards Program”) program through the
          Sites. Please refer to the Farmland Deli Points for Everything Terms
          of Use for more information about the terms, conditions and policies
          that apply to your registration and use of the Rewards Program. Mobile
          Features Some Users may be able to elect to participate in certain
          functionality on certain of the Sites, which will allow the User in
          certain markets or locations to pay for, order, or access a platform
          to order delivery of Farmland Deli products. These include: ● Mobile
          Payment, which allows Users to purchase Farmland Deli products
          directly via the Sites using a credit card, debit card or mobile
          wallet (“Mobile Payment”). Please see the Points for Everything Terms
          of Use for more details on the benefits associated with different
          mobile payment methods, and please note that some payment vehicles may
          charge a nominal fee if they link directly to your account. ● Mobile
          Order and Pay (MOP), which allows Users to use the Sites to order and
          pay for certain Farmland Deli products prior to arrival at the store
          (“MOP”). ● In-App Delivery, which allows Users to access via the Sites
          a platform for ordering delivery of Farmland Deli products to the
          User’s location (“In-App Delivery”). This feature is enabled via
          online third-party platform(s) which connect Users with Farmland Deli
          stores and the platform’s third-party delivery contractors. All
          deliveries will be made by such contractors, and neither Farmland Deli
          nor its employees will provide delivery themselves. Users may be
          subject to third party terms, including the DoorDash Consumer Terms
          and Conditions. Farmland Deli has no liability or responsibility for
          the acts or omissions of any third-party platform or delivery
          contractor, including with respect to food and product handling. The
          third-party platform shall handle all fees and payments with respect
          to any delivery order, and prices for Farmland Deli products ordered
          through In-App Delivery may differ from prices charged at stores or
          via MOP. With respect to all Mobile Features, Farmland Deli reserves
          the right at any time to (a) limit ordering options or the
          availability of certain products, including a limit of twelve (12) or
          fewer of each potential beverage modifier (e.g., number of espresso
          shots, number of pumps of flavored syrup, etc.) per each MOP item
          ordered; (b) discontinue any or all of these Mobile Features; (c)
          change the location of markets or stores accepting these features;
          and/or (d) change the ordering options and limitations for items
          available through these features. Any delivery, pickup, or preparation
          times displayed via the Sites or the third-party platform are
          estimates and do not represent a commitment or guarantee. Email
          Communications and Messages If a User signs up for a Farmland Deli
          account on the Sites, the User is, by default, opted in to receive
          promotional email communications from Farmland Deli (“Email
          Communications”). The User may, at the time of sign up, opt out of
          receiving Email Communications from Farmland Deli. Thereafter, the
          User may opt out of receiving Email Communications by adjusting the
          User’s profile settings in the User’s Farmland Deli account via
          https://farm-land-deli-app.vercel.app/ By using the Sites, including
          the web application, in-app messages may automatically be displayed to
          the User via the display tiles, including promotional communications
          and offers. If the User does not wish to see or receive such messages,
          the User must cease use of the Site. Copyright, Trademarks, and User
          License Unless otherwise indicated, the Sites and all content and
          other materials therein, including, without limitation, the Farmland
          Deli logo and all designs, text, graphics, pictures, information,
          data, software, sound files, other files and the selection and
          arrangement thereof (collectively, “Site Materials”) are the property
          of Farmland Deli or its licensors or users and are protected by U.S.
          and international copyright laws. Quick Catering Service Inc.,
          Farmland Deli, the Farmland Deli logo, and other Farmland Deli
          trademarks, service marks, graphics, and logos used in connection with
          the Sites are trade names, trademarks or registered trademarks of
          Quick Catering Service Inc. (collectively “Farmland Deli Marks”).
          Other trademarks, service marks, graphics and logos used in connection
          with the Sites are the trademarks or registered trademarks of their
          respective owners (collectively “Third Party Marks”). The Farmland
          Deli Marks and Third-Party Marks may not be copied, imitated, or used,
          in whole or in part, without the prior written permission of Farmland
          Deli or the applicable trademark holder. The Sites and the Content are
          protected by copyright, trademark, patent, trade secret, international
          treaties, state and federal laws, and other proprietary rights and
          also may have security components that protect digital information
          only as authorized by Farmland Deli or the owner of the Content. All
          rights not expressly granted are reserved. Subject to these Terms,
          Farmland Deli grants the User a personal, non-exclusive,
          non-transferable, limited, and revocable license to use the Sites for
          personal use only in accordance with these Terms (“User License”). Any
          use of the Sites in any other manner, including, without limitation,
          resale, transfer, modification or distribution of the Sites or text,
          pictures, music, barcodes, video, data, hyperlinks, displays, and
          other content associated with the Sites (“Content”) is prohibited.
          Unless explicitly stated herein, nothing in these Terms shall be
          construed as conferring in any manner, whether by implication,
          estoppel or otherwise, any title or ownership of, or exclusive
          use-rights to, any intellectual property or other right and any
          goodwill associated therewith These Terms and User License also govern
          any updates to, or supplements or replacements for, the Sites, unless
          separate terms accompany such updates, supplements, or replacements,
          in which case the separate terms will apply. Digital Millennium
          Copyright Act ("DMCA") Notice If you believe any material available
          via the Sites infringes a copyright you own or control, you may file a
          notification of such infringement with our Designated Agent as set
          forth below. Quick Catering Servce Inc. 11910 Parrklawn Dr. Suite O
          Rockville MD 20852. Please see 17 U.S.C. §512(c)(3) for the
          requirements of a proper notification. You should note that if you
          knowingly misrepresent in your notification that the material or
          activity is infringing, you will be liable for any damages, including
          costs and attorneys' fees, incurred by us or the alleged infringer as
          the result of our relying upon such misrepresentation in removing or
          disabling access to the material or activity claimed to be infringing.
          If a notice of copyright infringement has been filed against material
          posted by you on the Sites, you may make a counter-notification with
          our Designated Agent listed above, provided that such
          counter-notification complies with the requirements of 17 U.S.C.
          §512(g)(3). If Farmland Deli receives a valid counter-notification, it
          may reinstate the removed or disabled material in accordance with the
          DMCA. In accordance with the DMCA and other applicable law, Farmland
          Deli has also adopted a policy of terminating, in appropriate
          circumstances and in our sole discretion, users who are deemed to be
          repeat infringers. Farmland Deli may also, in its sole discretion,
          limit access to the Sites and/or terminate the accounts of any users
          who infringe any intellectual property rights of others, whether or
          not there is any repeat infringement. Acceptable Use User’s use of the
          Sites, any Content, and any information provided by the User including
          user names and passwords, addresses, e-mail addresses, phone number,
          financial information (such as credit card numbers), employer name, or
          GPS location (“User Information”) transmitted in connection with the
          Sites is limited to the contemplated functionality of the Sites. In no
          event may the Sites be used in a manner that (a) harasses, abuses,
          stalks, threatens, defames, or otherwise infringes or violates the
          rights of any other party (including but not limited to rights of
          publicity or other proprietary rights); (b) is unlawful, fraudulent,
          or deceptive; (c) provides sensitive personal information unless
          specifically requested by Farmland Deli, (d) includes spam or any
          unsolicited advertising; (e) uses technology or other means to access
          Farmland Deli or Content that is not authorized by Farmland Deli; (f)
          uses or launches any automated system, including without limitation,
          “robots,” “spiders,” or “offline readers,” to access Farmland Deli or
          Content; (g) attempts to introduce viruses or any other computer code,
          files, or programs that interrupt, destroy, or limit the functionality
          of any computer software, hardware, or telecommunications equipment;
          (h) attempts to gain unauthorized access to Farmland Deli’s computer
          network or user accounts; (i) encourages conduct that would constitute
          a criminal offense or that gives rise to civil liability; (j) violates
          these Terms; (k) attempts to damage, disable, overburden, or impair
          Farmland Deli’s servers or networks; (l) impersonates any person or
          entity or otherwise misrepresents your identity or affiliation with
          another person or entity; or (m) fails to comply with applicable third
          party terms (collectively “Acceptable Use”). Farmland Deli reserves
          the right, in its sole discretion, to terminate any User License,
          terminate any User’s participation in the Sites (including the Mobile
          Features), remove Content, or assert legal action with respect to
          Content or use of the Sites, including Mobile Features, that Farmland
          Deli reasonably believes is or might be in violation of these Terms,
          or Farmland Deli policies including the Farmland Deli Rewards Program
          Terms and Conditions. Farmland Deli’ failure or delay in taking such
          actions does not constitute a waiver of its rights to enforce these
          Terms. Farmland Deli requests that Users not use the Sites, including
          that they not place orders through Mobile Features, while driving.
          User Content Farmland Deli does not control, take responsibility for
          or assume liability for any User Content posted, stored or uploaded by
          you or any third party, or for any loss or damage thereto, nor is
          Farmland Deli liable for any user conduct or any mistakes, defamation,
          slander, libel, omissions, falsehoods, obscenity, pornography or
          profanity you may encounter. The interactive areas are generally
          designed as open and public community areas for connecting and sharing
          with other people. When you participate in these areas, you understand
          that certain information and content you choose to post may be
          displayed publicly. You are solely responsible for your use of the
          Sites and agree to use the interactive areas at your own risk. If you
          become aware of User Content that you believe violates these Terms
          (with the exception of copyright infringement which is addressed in
          the Digital Millennium Copyright Act Notice section), you may report
          it by clicking on the "Report Abuse" or "Flag" links located just
          below each piece of User Content. Enforcement of these Terms however,
          is solely in our discretion and absence of enforcement in some
          instances does not constitute a waiver of our right to enforce the
          Terms in other instances. In addition, these Terms do not create any
          private right of action on the part of any third party or any
          reasonable expectation or promise that the Sites will not contain any
          content that is prohibited by these Terms. Although Farmland Deli has
          no obligation to screen, edit or monitor any of the User Content
          posted on the Sites, Farmland Deli reserves the right, and has
          absolute discretion, to remove, screen or edit any User Content on the
          Sites at any time and for any reason without notice. You are solely
          responsible for creating backup copies and replacing any User Content
          you post or store on the Sites at your sole cost and expense. If you
          are viewing the Sites on a public computer or are otherwise using a
          computer to which multiple people have potential access, be sure to
          follow all relevant instructions to ensure you are sufficiently
          disconnected and logged off the Sites and the computer system you are
          using to prevent unauthorized User Content. You represent and warrant
          that your User Content is not subject to any confidentiality
          obligations and that you own and control all of the rights to the User
          Content, have the lawful right to distribute and produce such User
          Content, or otherwise have the right to grant the rights to Farmland
          Deli that you grant herein. Farmland Deli claims no ownership or
          control over any User Content, except as otherwise provided herein, on
          the Sites or in a separate agreement. However, by submitting or
          posting User Content on the Sites, you grant Farmland Deli and its
          designees a worldwide, perpetual, irrevocable, non-exclusive,
          fully-paid up and royalty free license to use, sell, reproduce,
          prepare derivative works, combine with other works, alter, translate,
          distribute copies, display, perform, publish, license or sub-license
          the User Content and your name and likeness provided in connection
          with such use of your User Content. By posting User Content, you
          hereby release Farmland Deli and its agents and employees from any
          claims that such use, as authorized above, violates any of your rights
          and you understand that you will not be entitled to any compensation
          for any use of your User Content. Submission of Ideas Separate and
          apart from the User Content you provide, you may submit questions,
          comments, feedback, suggestions, ideas, improvements, plans, notes,
          drawings, original or creative materials or other information about
          Farmland Deli, our Sites and our products (collectively, "Ideas"). The
          Ideas you submit are voluntary, non-confidential, gratuitous and
          non-committal. Please do not send us Ideas if you expect to be paid or
          want to continue to own or claim rights in them; your Ideas might be
          great, but we may have already had the same or similar idea and we do
          not want disputes. You must also inform us if you have a pending or
          registered patent relative to the Idea. You represent and warrant that
          your Idea is not subject to any confidentiality obligations or third
          party intellectual property encumbrances and that you own and control
          all of the rights to the Idea and have the authority to grant the
          rights to Farmland Deli that you grant herein. By submitting your
          Idea, you grant Farmland Deli and its designees a worldwide,
          perpetual, irrevocable, non-exclusive, fully-paid up and royalty free
          license to use, sell, reproduce, prepare derivative works, combine
          with other works, alter, translate, distribute copies, display,
          perform, publish, license or sub-license the Idea and shall be
          entitled to the unrestricted use and dissemination of Ideas for any
          purpose, commercial or otherwise, without acknowledgment or
          compensation to you. By submitting your Idea, you hereby release
          Farmland Deli and its agents and employees from any claims that such
          use violates any of your rights. Farmland Deli shall own exclusive
          rights, including all intellectual property rights, to any work it
          creates or has created from the Idea or a similar idea of its own.
          Links to Sites You are granted a limited, non-exclusive right to
          create text hyperlinks to the Sites for noncommercial purposes,
          provided such links do not portray Farmland Deli in a false,
          misleading, derogatory or otherwise defamatory manner and provided
          further that the linking site does not contain any obscene,
          pornographic, sexually explicit or illegal material or any material
          that is offensive, harassing or otherwise objectionable. This limited
          right may be revoked at any time. In addition, you may not use
          Farmland Deli's logo or other proprietary graphics to link to our
          Sites without our express written permission. Further, you may not
          use, frame or utilize framing techniques to enclose any Farmland Deli
          trademark, logo or other proprietary information, including the images
          found at the Sites, the content of any text or the layout/design of
          any page or form contained on a page on the Sites without our express
          written consent. Except as noted above, you are not conveyed any right
          or license by implication, estoppel or otherwise in or under any
          patent, trademark, copyright or proprietary right of Farmland Deli or
          any third party. Farmland Deli makes no claim or representation
          regarding, and accepts no responsibility for, the quality, content,
          nature or reliability of websites linking to the Sites. Such sites are
          not under the control of Farmland Deli and Farmland Deli is not
          responsible for the content of any linked site or any link contained
          in a linked site, or any review, changes or updates to such sites.
          Indemnification The User agrees to defend, indemnify, and hold
          harmless Farmland Deli, its parent, subsidiary and other affiliated
          companies, independent contractors, service providers and consultants,
          and their respective employees, contractors, agents, officers, and
          directors (“Farmland Deli Indemnitees”) from any and all claims,
          suits, damages, costs, lawsuits, fines, penalties, liabilities, and
          expenses (including attorneys’ fees) (“Claims”) that arise from or
          relate to the User’s use or misuse of the Sites,(including Mobile
          Features), violation of these Terms, violation of any rights of a
          third party, any User Content or Ideas you provide, or your conduct in
          connection with the Sites. Notwithstanding the foregoing, this
          indemnification provision shall not apply to any Claims caused by a
          Farmland Deli Indemnitee’s sole negligence. Farmland Deli reserves the
          right to assume the exclusive defense and control of any matter
          otherwise subject to indemnification by the User, in which event the
          User will cooperate in asserting any available defenses. Warranties;
          Disclaimers Farmland Deli IS PROVIDING THE SITES TO THE USER “AS IS”
          AND THE USER IS USING THE SITES AT HIS OR HER OWN RISK. TO THE FULLEST
          EXTENT ALLOWABLE UNDER APPLICABLE LAW, Farmland Deli DISCLAIMS ALL
          WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING ANY WARRANTIES THAT
          THE SITES ARE MERCHANTABLE, RELIABLE, AVAILABLE, ACCURATE, FIT FOR A
          PARTICULAR PURPOSE OR NEED, NON-INFRINGING, FREE OF DEFECTS OR
          VIRUSES, ABLE TO OPERATE ON AN UNINTERRUPTED BASIS, THAT THE USE OF
          THE SITES BY THE USER IS IN COMPLIANCE WITH LAWS APPLICABLE TO THE
          USER, THAT USER INFORMATION OR ORDERS TRANSMITTED IN CONNECTION WITH
          THE SITES (INCLUDING AS PART OF MOBILE FEATURES) WILL BE SUCCESSFULLY,
          ACCURATELY, OR SECURELY TRANSMITTED OR RECEIVED, THAT ORDERS WILL BE
          AS PLACED OR READY AT THE SUGGESTED TIME, OR THAT ANY PARTICULAR ITEM
          ORDERED WILL BE AVAILABLE. THE MATERIALS AND INFORMATION ON THE SITES
          MAY INCLUDE TECHNICAL INACCURACIES OR TYPOGRAPHICAL ERRORS.
          NOTWITHSTANDING THE FOREGOING, NONE OF THE DISCLAIMERS IN THIS
          PARAGRAPH SHALL APPLY TO WARRANTIES RELATED TO PERSONAL INJURY. No
          Liability SUBJECT TO APPLICABLE LAW, INCLUDING WITH RESPECT TO
          LIABILITY FOR PERSONAL INJURY OR NON-WAIVABLE STATUTORY RIGHTS UNDER
          NEW JERSEY LAW, IN NO EVENT SHALL Farmland Deli OR ITS OFFICERS,
          DIRECTORS, EMPLOYEES, SHAREHOLDERS OR AGENTS (A) BE LIABLE TO THE USER
          WITH RESPECT TO USE OF THE SITES, THE CONTENT OR THE MATERIALS
          CONTAINED IN OR ACCESSED THROUGH THE SITES (INCLUDING WITHOUT
          LIMITATION PARTICIPATION IN MOBILE FEATURES, THE CONTENT OR THE
          MATERIALS CONTAINED IN OR ACCESSED THROUGH THE SITES, OR ANY DAMAGES
          CAUSED BY OR RESULTING FROM RELIANCE BY A USER ON ANY INFORMATION
          OBTAINED FROM Farmland Deli), OR ANY DAMAGES THAT RESULT FROM
          MISTAKES, OMISSIONS, INTERRUPTIONS, DELETION OF FILES OR EMAIL,
          ERRORS, DEFECTS, VIRUSES, DELAYS IN OPERATION OR TRANSMISSION OR ANY
          FAILURE OF PERFORMANCE, WHETHER OR NOT RESULTING FROM ACTS OF GOD,
          COMMUNICATIONS FAILURE, THEFT, DESTRUCTION OR UNAUTHORIZED ACCESS TO
          Farmland Deli' RECORDS, PROGRAMS OR SERVICES; AND (B) BE LIABLE TO THE
          USER FOR ANY INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL, PUNITIVE,
          OR EXEMPLARY DAMAGES, INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS
          OF GOODWILL, LOST PROFITS, LOSS, THEFT OR CORRUPTION OF USER
          INFORMATION, PERSONAL INJURY OR PROPERTY DAMAGE, THE INABILITY TO USE
          THE SITES OR ANY OF THEIR FEATURES OR DEVICE FAILURE OR MALFUNCTION.
          THE USER’S SOLE REMEDY IS TO CEASE USE OF THE SITES OR TO CEASE
          PARTICIPATION IN MOBILE FEATURES. IF YOU RESIDE IN A JURISDICTION
          OTHER THAN NEW JERSEY, YOUR JURISDICTION MAY NOT ALLOW THE LIMITATION
          OF LIABILITY IN CONTRACTS WITH CONSUMERS, SO SOME OR ALL OF THESE
          LIMITATIONS OF LIABILITY MAY NOT APPLY TO YOU. Third Party Content,
          Sites, Products and Services (including Advertising and Promotions)
          Farmland Deli may provide third party content on the Sites (including
          embedded content) or links to third-party web pages, content,
          applications, products and services, including advertisements and
          promotions (collectively, “Third Party Content”) as a service to those
          interested in such services or information. We do not control, endorse
          or adopt any Third-Party Content, including that the inclusion of any
          link does not imply affiliation, endorsement or adoption by Farmland
          Deli of any site or any information contained therein, and can make no
          guarantee as to its accuracy or completeness. You acknowledge and
          agree that Farmland Deli is not responsible or liable in any manner
          for any Third-Party Content or services provided by such third
          parties, and undertakes no responsibility to update or review such
          Third-Party Content. You agree to use such Third-Party Content or
          services contained therein at your own risk. When you use or visit
          other sites via Third-Party Content, or participate in promotions or
          business dealings with third parties, you should understand that our
          terms and policies no longer govern, and that the terms and policies
          of those third-party sites will now apply. You should review the
          applicable terms and policies, including privacy and data gathering
          practices, of any site to which you navigate from our Sites. You must
          comply with any applicable third-party terms when using the Sites.
          Modifications to the Sites Farmland Deli reserves the right to modify
          or discontinue, temporarily or permanently, the Sites or any features
          or portions thereof without prior notice. You agree that Farmland Deli
          will not be liable for any modification, suspension or discontinuance
          of the Sites or any part thereof. Financial Material Disclosures
          Forward-Looking Statements: The Sites, and any documents issued by
          Farmland Deli and available through the Sites, may contain statements
          which constitute forward-looking statements within the meaning of the
          U.S. Private Securities Litigation Reform Act of 1995. Forward-looking
          statements can be identified by the fact that they do not relate
          strictly to historical or current facts. They often include words such
          as “believes,” “expects,” “anticipates,” “estimates,” “intends,”
          “plans,” “seeks” or words of similar meaning, or future or conditional
          verbs, such as “will,” “should,” “could” or “may.” Forward-looking
          statements include statements made as to future operations, costs,
          capital expenditures, cash flow, product developments, operating
          efficiencies, sales and earnings estimates or trends and expansion
          plans, initiatives and projections. These forward-looking statements
          are based on our expectations as of the date such forward-looking
          statements are made and are neither predictions nor guarantees of
          future events or circumstances. Actual future results and trends may
          differ materially depending on a variety of factors including the
          risks detailed in the company’s filings with the Securities and
          Exchange Commission, including the “Risk Factors” section of Farmland
          Deli Annual Report on Form 10-K for the most recent fiscal year ended.
          The company assumes no obligation to update any of these
          forward-looking statements. Press Releases: The information contained
          within press releases issued by Farmland Deli should not be deemed
          accurate or current except as of the date the release was posted.
          Farmland Deli specifically disclaims any duty to update, the
          information in the press releases. To the extent any information
          therein is forward-looking it is intended to fit within the safe
          harbor for forward-looking statements and is subject to material risk.
          Third-Party Financial Information: As a service, Farmland Deli may
          provide links to third-party websites or services that contain
          financial or investment information about Farmland Deli. Farmland Deli
          neither regularly monitors nor has control over the content of third
          parties' statements or websites. Accordingly, Farmland Deli does not
          endorse or adopt, nor make any representations or warranties
          whatsoever regarding the accuracy or completeness, of those websites
          or any information contained therein, including, without limitation,
          analysts' reports and stock quotes. Users visit these websites and use
          the information contained therein at their own risk. Dispute
          Resolution (including Arbitration Agreement; Class Action Waiver; Jury
          Trial Waiver) Please read this section carefully. It affects your
          legal rights. It provides for resolution of most disputes through
          individual arbitration instead of court trials and class actions.
          Arbitration is more informal than a lawsuit in court, uses a neutral
          arbitrator instead of a judge or jury, and discovery is more limited.
          Arbitration is final and binding and subject to only very limited
          review by a court. This section also contains a jury trial waiver and
          a waiver of any and all rights to proceed in a class, collective,
          consolidated, private attorney general or representative action in
          arbitration, or litigation to the fullest extent allowable by
          applicable law. Arbitration Agreement. ● Binding Arbitration. This
          provision is intended to be interpreted broadly. Any dispute or claim
          arising out of or relating to these Terms, your use of the Sites, or
          your relationship with Farmland Deli or any past, present, or future
          subsidiary, parent or affiliate company or companies, whether based in
          contract, tort, statute, fraud, misrepresentation, or any other legal
          theory, (“Dispute”) will be resolved through binding individual
          arbitration, except that either of us may take a Dispute to small
          claims court so long as it isn’t removed or appealed to a court of
          general jurisdiction. Dispute shall include, but not be limited to:
          (a) any dispute or claim that arose before the existence of these or
          any prior Terms (including, but not limited to, claims relating to
          advertising); (b) any dispute or claim that is currently the subject
          of purported class action litigation in which you are not a member of
          a certified class; and (c) any dispute or claim that may arise after
          termination of these Terms. Dispute, however, does not include
          disagreements or claims concerning patents, copyrights, trademarks,
          and trade secrets and claims of piracy or unauthorized use of
          intellectual property. The arbitrator shall decide all issues except
          the following (which are for a court of competent jurisdiction to
          decide): (a) issues that are reserved for a court in these Terms; (b)
          issues that relate to the scope, validity, and enforceability of the
          arbitration agreement, class action waiver, or any of the provisions
          of this Dispute Resolution section; and (c) issues that relate to the
          arbitrability of any Dispute. These Terms and this arbitration
          agreement do not prevent you from bringing a Dispute to the attention
          of any government agency. You and we agree that these Terms evidence a
          transaction in interstate commerce and that this arbitration agreement
          will be interpreted and enforced in accordance with the Federal
          Arbitration Act and federal arbitration law. ● Mandatory Informal
          Dispute Resolution Process. You and we agree to work together in an
          effort to informally resolve any Dispute between us. The party
          initiating the Dispute must send the other a written notice of the
          Dispute that includes all of this information: (a) information
          sufficient to identify any transaction and account at issue; (b)
          contact information (including name, address, telephone number, and
          email address); and (c) a detailed description of the nature and basis
          of the Dispute and the relief sought, including a calculation for it.
          The notice must be personally signed by the party initiating the
          Dispute (and their counsel, if represented). If you have the Dispute
          with us, you must send this notice to our Customer Service department
          using the appropriate link at https://farmlanddeli.com. If we have a
          Dispute with you, we will send this notice to the most recent contact
          information we have for you. For a period of 60 days from receipt of a
          completed notice (which can be extended by agreement of the parties),
          you and we agree to negotiate in good faith in an effort to informally
          resolve the Dispute. The party receiving the notice may request a
          telephone settlement conference to aid in the resolution of the
          Dispute. If such a conference is requested, you and a Farmland Deli
          representative will personally attend (with counsel, if represented).
          The conference will be scheduled for a mutually convenient time, which
          may be outside of the 60-day period. Completion of this Mandatory
          Informal Dispute Resolution Process (“Process”) is a condition
          precedent to initiating a claim in arbitration. If the sufficiency of
          a notice or compliance with this Process is at issue, such issue may
          be raised with and decided by a court of competent jurisdiction at
          either party’s election, and any arbitration shall be stayed. The
          court shall have the authority to enforce this condition precedent to
          arbitration, which includes the power to enjoin the filing or
          prosecution of arbitrations and the assessment or collection of
          arbitration fees. Nothing in this paragraph limits the right of a
          party to seek damages for non-compliance with this Process in
          arbitration. All applicable limitations periods (including statutes of
          limitations) will be tolled from the date of receipt of a completed
          notice through the conclusion of this Process. You or we may commence
          arbitration if the Dispute is not resolved through this Process. ●
          Arbitration Procedures. The arbitration of any Dispute shall be
          administered by and conducted in accordance with the rules of the
          American Arbitration Association (“AAA”), including the AAA’s Consumer
          Arbitration Rules (as applicable) (“AAA Rules”), as modified by this
          arbitration agreement. The AAA Rules are available online at
          www.adr.org. You and we understand and agree that the AAA’s
          administrative determination that this arbitration agreement comports
          with the Consumer Due Process Protocols is final and that neither a
          court nor an arbitrator has the authority to revisit it. If the AAA is
          unavailable or unwilling to administer the arbitration consistent with
          this arbitration agreement, the parties shall agree on an
          administrator that will do so. If the parties cannot agree, they shall
          petition a court of competent jurisdiction to appoint an administrator
          that will do so. An arbitration demand must be accompanied by a
          certification of compliance with the Process and be personally signed
          by the party initiating arbitration (and counsel, if represented). By
          submitting an arbitration demand, the party and counsel represent
          that, as in court, that they are complying with the requirements of
          Federal Rule of Civil Procedure 11(b). The arbitrator is authorized to
          impose any sanctions available under Federal Rule of Civil Procedure
          11 on represented parties and their counsel. You may choose to have
          the arbitration conducted by a phone, video, or in-person hearing, or
          through written submissions, except any Dispute seeking $25,000 or
          more, or injunctive relief, shall have an in-person or video hearing
          unless the parties agree otherwise. You and we reserve the right to
          request a hearing in any matter from the arbitrator. You and a
          Farmland Deli representative will personally appear at any hearing
          (with counsel, if represented). Any in-person hearing will be held in
          the county or parish in which you reside or at another mutually agreed
          location. An arbitrator may award on an individual basis any relief
          that would be available in a court, including injunctive or
          declaratory relief only in favor of the individual party seeking
          relief and only to the extent necessary to provide relief warranted by
          that party’s individual claim. To the fullest extent allowable by
          applicable law, you and we agree that each may bring claims against
          the other only in your or our individual capacity and not as a
          plaintiff or class member in any purported class, collective,
          consolidated, private attorney general, or representative proceeding.
          Further, unless both you and we agree otherwise, an arbitrator may not
          consolidate more than one person’s claims and may not otherwise
          preside over any form of class, collective, consolidated, private
          attorney general, or representative proceeding. An arbitrator must
          follow and enforce these Terms as a court would. If, after exhaustion
          of all appeals, any of these prohibitions on non-individualized
          injunctive or declaratory relief and class, collective, consolidated,
          private attorney general, or representative proceedings are found to
          be unenforceable with respect to a particular claim or request for
          relief (such as a request for public injunctive relief), then such a
          claim or request for relief will be decided by a court of competent
          jurisdiction, after all other claims and requests for relief are
          arbitrated. The arbitrator shall issue a reasoned written decision
          sufficient to explain essential findings and conclusions. The
          arbitrator shall apply the cost-shifting provisions of Federal Rule of
          Civil Procedure 68 after entry of an award. Judgment on any
          arbitration award may be entered in any court of competent
          jurisdiction, except an award that has been satisfied may not be
          entered. An award shall have no preclusive effect in any other
          arbitration or proceeding in which you are not a named party. ● Costs
          of Arbitration. Payment of arbitration fees will be governed by the
          AAA Rules and fee schedule. You and we agree that the parties have a
          shared interest in reducing the costs and increasing the efficiencies
          associated with arbitration. Therefore, you or we may elect to engage
          with the AAA regarding arbitration fees, and you and we agree that the
          parties (and counsel, if represented) will work together in good faith
          to ensure that arbitration remains cost-effective for all parties. ●
          Additional Procedures for Multiple Case Filings. You and we agree that
          these Additional Procedures for Multiple Case Filings (in addition to
          the other provisions of this arbitration agreement) shall apply if you
          choose to participate in a Multiple Case Filing. If 25 or more similar
          Disputes (including yours) are asserted against Farmland Deli by the
          same or coordinated counsel or are otherwise coordinated (“Multiple
          Case Filing”), the resolution of your Dispute might be delayed and
          ultimately proceed in court. The parties agree that as part of these
          procedures, their counsel shall meet and confer in good faith in an
          effort to resolve the Disputes, streamline procedures, address the
          exchange of information, modify the number of Disputes to be
          adjudicated, and conserve the parties’ and the AAA’s resources. If
          your claim is part of a Multiple Case Filing, any applicable
          limitations periods (including statutes of limitations) shall be
          tolled for your Dispute from the time that your Dispute is first
          submitted to the AAA until your Dispute is selected to proceed as part
          of a staged process or is settled, withdrawn, otherwise resolved, or
          opted out of arbitration pursuant to this provision. STAGE ONE: If at
          least 100 Disputes are submitted as part of the Multiple Case Filing,
          counsel for the claimants and counsel for Farmland Deli shall each
          select 50 Disputes to be filed and to proceed as cases in individual
          arbitrations as part of this initial staged process. The number of
          Disputes to be selected to proceed in Stage One can be increased by
          agreement of counsel for the parties (and if there are fewer than 100
          Disputes, all shall proceed individually in Stage One). Each of the
          100 (or fewer) cases shall be assigned to a different arbitrator and
          proceed individually. If a case is withdrawn before the issuance of an
          arbitration award, another claim shall be selected to proceed as part
          of Stage One. The remaining Disputes shall not be filed or deemed
          filed in arbitration nor shall any arbitration fees be assessed or
          collected in connection with those claims. After this initial set of
          proceedings, counsel for the parties shall participate in a global
          mediation session with a retired federal or state court judge jointly
          selected by counsel in an effort to resolve the remaining Disputes (as
          informed by the adjudications of cases in Stage One), and Farmland
          Deli shall pay the mediator’s fee. STAGE TWO: If the remaining
          Disputes have not been resolved at the conclusion of Stage One,
          counsel for the claimants and counsel for Farmland Deli shall each
          select 100 Disputes per side to be filed and to proceed as cases in
          individual arbitrations as part of a second staged process. The number
          of Disputes to be selected to proceed as part of this second staged
          process can be increased by agreement of counsel for the parties (and
          if there are fewer than 200 Disputes, all shall proceed individually
          in Stage Two). No more than five cases may be assigned to a single
          arbitrator to proceed individually. If a case is withdrawn before the
          issuance of an arbitration award, another claim shall be selected to
          proceed as part of Stage Two. The remaining Disputes shall not be
          filed or deemed filed in arbitration nor shall any arbitration fees be
          assessed or collected in connection with those claims. After this
          second set of staged proceedings, the parties shall engage in a global
          mediation session of all remaining Disputes with a retired federal or
          state court judge jointly selected by counsel in an effort to resolve
          the remaining Disputes (as informed by the adjudications of cases in
          Stages One and Two), and Farmland Deli shall pay the mediator’s fee.
          Upon the completion of the mediation set forth in Stage Two, each
          remaining Dispute (if any) that is not settled or not withdrawn shall
          be opted out of arbitration and may proceed in a court of competent
          jurisdiction consistent with the remainder of the Terms.
          Notwithstanding the foregoing, counsel for the parties may mutually
          agree in writing to proceed with the adjudication of some or all of
          the remaining Disputes in individual arbitrations consistent with the
          process set forth in Stage Two (except Disputes shall be randomly
          selected and mediation shall be elective by agreement of counsel) or
          through another mutually-agreeable process. A court of competent
          jurisdiction shall have the authority to enforce the Additional
          Procedures for Multiple Case Filings, including the power to enjoin
          the filing or prosecution of arbitrations and the assessment or
          collection of arbitration fees. The Additional Procedures for Multiple
          Case Filings provision and each of its requirements are essential
          parts of this arbitration agreement. If, after exhaustion of all
          appeals, a court of competent jurisdiction decides that the Additional
          Procedures for Multiple Case Filings apply to your Dispute and are not
          enforceable, then your Dispute shall not proceed in arbitration and
          shall only proceed in a court of competent jurisdiction consistent
          with the remainder of the Terms. ● Future Changes to Arbitration
          Agreement. If we make any future changes to this arbitration agreement
          (other than a change to our contact information), you may reject any
          such change by sending your personally signed, written notice to the
          following address within 30 days of the change: Quick Catering Servce
          Inc. 11910 Parrklawn Dr. Suite O Rockville MD 20852. Attention:
          Litigation Department Such written notice does not constitute an opt
          out of arbitration altogether. By rejecting any future change, you are
          agreeing that you will arbitrate any Dispute between you and Farmland
          Deli in accordance with this version of the arbitration agreement.
          Class Action Waiver and Jury Trial Waiver. ● You and we each agree
          that any proceeding, whether in arbitration or in court, will be
          conducted only on an individual basis and not in a class, collective,
          consolidated, private attorney general, or representative action. You
          and we agree to waive any right to bring or to participate in such an
          action in arbitration or in court to the fullest extent allowable by
          applicable law. Notwithstanding the foregoing, the parties retain the
          right to participate in a class-wide settlement. ● To the fullest
          extent allowable by applicable law, you and we waive the right to a
          jury trial. Governing Law and Jurisdiction These Terms and use of the
          Sites are governed by the laws of the state of Washington, United
          States of America, without regard to Washington’s conflict of laws
          rules. The United Nations Convention on Contracts for the
          International Sale of Goods shall have no applicability. If the
          arbitration agreement is ever deemed unenforceable or void, or a
          dispute between the parties is not subject to arbitration, the User
          irrevocably consents to the exclusive jurisdiction of the federal and
          state courts in King County, Washington, United States of America, for
          purposes of any legal action arising out of or related to the use of
          the Sites or these Terms, and waives any objections as to personal
          jurisdiction or as to the laying of venue in such courts due to: (a)
          inconvenient forum or (b) any other basis or any right to seek to
          transfer or change venue of any such action to another court.
          Termination Notwithstanding any of these Terms, Farmland Deli reserves
          the right, without notice and in its sole discretion, to terminate
          your license to use the Sites and to block or prevent your future
          access to and use of the Sites. Farmland Deli’ failure or delay in
          taking such actions does not constitute a waiver of its rights to
          enforce these Terms. Changes Farmland Deli reserves the right to
          change or modify these Terms or any other Farmland Deli policies
          related to use of the Sites at any time and at its sole discretion by
          posting revisions on the Sites. Continued use of the Sites following
          such changes or modifications to the Terms or other Farmland Deli
          policies will constitute acceptance of such changes or modifications.
          If you do not agree to such changes or modifications, you should cease
          using the Sites immediately. Severability and Survival Except as
          otherwise provided herein, if any provision of these Terms shall be
          deemed unlawful, void or for any reason unenforceable, then that
          provision shall be deemed severable from these Terms and shall not
          affect the validity and enforceability of any remaining provisions. In
          addition to such other provisions hereof which, by their terms,
          survive any termination or expiration of this Agreement, the following
          sections shall survive termination of these Terms: (a)
          Indemnification; (b) Warranties; Disclaimers; (c) No Liability; (d)
          Dispute Resolution (including Arbitration Agreement; Class Action
          Waiver; Jury Trial Waiver); and (e) Governing Law and Jurisdiction.
          Notice to California Residents Under California Civil Code Section
          1789.3, California residents are entitled to the following specific
          consumer rights information: the provider of the Sites is Farmland
          Deli Corporation, 2401 Utah Avenue South, Seattle WA 98134. To file a
          complaint regarding the Sites or to receive further information
          regarding use of the Sites, send a letter to the above address or
          contact Farmland Deli via e-mail (with “California Resident Request”
          as the Subject Line). You may also contact the Complaint Assistance
          Unit of the Division of Consumer Services of the Department of
          Consumer Affairs in writing at 1625 North Market Blvd., Suite N 112,
          Sacramento CA 95834 or by telephone at 800.952.5210. Contact Except as
          otherwise provided in these Terms, any questions, complaints, or
          claims regarding the Sites should be directed to: Quick Catering
          Servce Inc. 11910 Parrklawn Dr. Suite O Rockville MD 20852.
        </Text>

        <Text
          style={{
            fontSize: 18,
            fontWeight: "600",
            marginTop: 20,
            color: "#111827",
          }}
        >
          Last Revised: September 2024
        </Text>

        {/* Botón de salir al final */}
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={{
            marginTop: 30,
            backgroundColor: "#3b82f6",
            paddingVertical: 12,
            borderRadius: 8,
            alignItems: "center",
          }}
        >
          <Text style={{ color: "white", fontSize: 16, fontWeight: "bold" }}>
            Back
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
