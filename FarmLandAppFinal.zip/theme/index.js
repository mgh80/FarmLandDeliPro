export const themeColors = {
  text: "#973a16",
  bgColor: (opacity) => `rgba(251, 146, 60, ${opacity})`,
};
